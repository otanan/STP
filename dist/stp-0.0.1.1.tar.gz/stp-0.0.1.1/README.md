# Project Name
> Stochastic Thermodynamics in Python (STP)

## Table of contents
* [General info](#general-info)
* [Setup](#setup)

## General info
Pass.

## Setup
In the base folder with where setup.py is located and in a virtual environment with Python 3.5+ just run
`python3 -m pip install .`

You can read the documentation for STP in docs/build/index.html.